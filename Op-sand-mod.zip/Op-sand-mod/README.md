#Op Sand Mod
turns sand very op

#Blocks
Sand Morphers - turns sand to the specific type of item
Sand Checker - turns sand storable
Magic Dust Maker - turns thorium to magic dust
Sand Brewery -turns sand and magic dust to hallowed sand

#Power
Sand Reactor - turns Sand to power. Takes a ver very long time

#Turrets
Dust Devil
Magic Shotgun

#Units
Sand Builder - like phantom builder drones but faster  and has lower health
Sand Healer - like spirit repair drones but faster and has lower health
Sand Crawler - like crawlers but faster more damgae and is 1 health
shock tanks -very powerful high health tanks