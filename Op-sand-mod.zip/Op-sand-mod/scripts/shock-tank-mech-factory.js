speed = 20;
const plantTaron = extendContent(unitFactory, "shock-tank-mech-factory", {
drawLayer(tile){
Draw.rect(this.name + "-rotator", tile.drawx(), tile.drawy(), tile.entity.totalProgress*speed + 10);
}
});
plantTaron.layer = Layer.turret
